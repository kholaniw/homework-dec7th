module homework4 {

	public static void main(String[] args) { // TODO Auto-generated method stub
		double[] x = { 1.00, 3.00, 2.00};
		value = isStrictlyIncreasing(x); //System.out.println(value);
		Character [] y = { 'b', 'd', 'a', 'b', 'f', 'm', 'g', 'n', 'a','f'}; // b d a f g
		Character [] value1 = removeDuplicates(y); for (Character character : value1) {
		//System.out.println(character);
		}
		int[] z = { 0, 1, 3, 2, 3, 0, 3,1};
		int[] value3 = remove(5,z); for (int i : value3) {
		//System.out.println(i);
		}
		int[] order1 = {1,2,3,4,5};
		int[] order2 = {0,0,0,2,1}; // 6 6 6 6 6 6
		int[] value4 = combineOrder(order1,order2); for (int i : value4) {
		System.out.println(i);
		} }
		public static boolean isStrictlyIncreasing(double[] in) { // 6 7 8 9 10 boolean result = true;
		for(int i=0; i< (in.length - 1); i++){
		if(in[i+1] <= in[i]) result = false;
		}
		return result;
		public static Character[] removeDuplicates(Character[] in) { // true true true boolean keepers[] = new boolean[in.length];
		// To start we indicate that each value will be kept for(int i=0; i<in.length; i++){
		keepers[i] = true;
		// Scan for duplicates starting with each character
		i=0; i<in.length; i++){
		// Only scan the rest if not a duplicate if(keepers[i])
		for(int j=i+1; j<in.length; j++){ if(in[i] == in[j])
		keepers[j] = false;
		boolean
		} for(int
		} }
		// Find
		int count = 0;
		for(int i=0; i<in.length; i++){
		               if(keepers[i])
		               count++;
		}
		// Create and copy non duplicates Character result[] = new Character[count]; int position = 0;
		for(int i=0; i<in.length; i++){
		if(keepers[i]){ result[position] = in[i]; position++;
		}
		       }
		       return result;
		}
		public static int[] remove(int v, int[] in){
		// Find the number of values that will be in the result int count = 0;
		for(int i=0; i<in.length; i++){
		if(in[i] != v) count++;
		}
		// Copy the values to the result int result[] = new int[count]; int position = 0;
		for(int i=0; i<in.length; i++){
		if(in[i] != v){ result[position] = in[i]; position++;
		}
		       }
		       return result;
		       }
		public static int[] combineOrder(int[] order1, int[] order2){
		// Find the number of values that will be in the result int[] combinedOrder = new int[5];
		for(int i=0; i<5; i++){
		combinedOrder[i] = order1[i] + order2[i]; }
		       return combinedOrder;
		   }